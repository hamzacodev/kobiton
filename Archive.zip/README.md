# react-tailwind-sidebar

1)npm i

2)npm run dev
